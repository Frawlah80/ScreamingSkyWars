---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

#### Describe the bug
A clear and concise description of what the bug is.

#### Server and plugin version
Spigot version:
BedWars version:

#### Installed plugins on server (can be obtained by `/pl`)

#### Console log

#### Configuration (of config.yml and shop.yml)

#### If there are problem with only one game, paste here config of this game
